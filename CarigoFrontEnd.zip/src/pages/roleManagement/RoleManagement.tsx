import RoleTable from "../../components/RoleTable/RoleTable";

const RoleManagement = () => {
  return <RoleTable />;
};

export default RoleManagement;
