import UserTable from "../../components/UserTable/UserTable";

const UserManagement = () => {
  return <UserTable />;
};

export default UserManagement;
