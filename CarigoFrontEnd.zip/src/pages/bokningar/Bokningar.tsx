import { useState } from "react";
import { X, RefreshCw, Menu } from "lucide-react";

const Bokningar = () => {
    return (
        <div className="max-w-full mx-auto font-plus-jakarta p-4">
            <section
                aria-label="Kalendervy filter"
                className="w-full rounded-xl border border-border/60 bg-background/80 shadow-sm backdrop-blur supports-[backdrop-filter]:bg-background/60"
            >
                <div className="px-4 py-3 sm:px-5 sm:py-4">
                    <div className="text-sm text-muted-foreground mb-2">Kalendervy</div>

                    <div className="flex flex-wrap items-center gap-3 sm:gap-4">
                        <label className="text-sm text-foreground/80">Status:</label>

                        <div role="group" aria-label="Status" className="flex items-center gap-2">
                            <button
                                type="button"
                                className="aktiva h-8 px-3 text-sm bg-primary/10 text-primary border-primary/40"
                            >
                                Aktiva
                            </button>
                            <button
                                type="button"
                                className="aktivaotherbuttons h-8 px-3 text-sm text-foreground/80 bg-background"
                            >
                                Alla
                            </button>
                        </div>

                        <div className="flex items-center gap-2">
                            <button
                                type="button"
                                className="aktivaotherbuttons h-8 px-3 text-sm text-foreground/80 bg-background"
                            >
                                Kund: Alla
                            </button>
                        </div>

                        <div className="hidden sm:flex items-center">
                            {/* <div className="h-[1px] w-6 bg-border/70" />
              <div className="mx-2 h-4 w-4 rounded-full border border-border bg-background shadow-[0_1px_0_0_rgba(0,0,0,0.03)]" />
              <div className="h-[1px] w-2 bg-border/70" /> */}
                            <label className="inline-flex items-center cursor-pointer">
                                <input
                                    type="checkbox"
                                    value=""
                                    className="sr-only peer"
                                />
                                <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600 dark:peer-checked:bg-blue-600"></div>
                            </label>

                        </div>

                        <div className="flex items-center gap-2">
                            <button
                                type="button"
                                className="aktivaotherbuttons h-8 px-3 text-sm text-foreground/80 bg-background"
                            >
                                Datum: (Oktober 2025)
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Bokningar;
