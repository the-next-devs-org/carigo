import React from "react";
// import { AlertCircle, Clock3, Shield, Search } from "lucide-react";

// const kpiBase =
//   "flex-1 min-w-[220px] bg-white border border-gray-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition";

// const numberBase = "font-extrabold tracking-tight";

// function onSearchSubmit(e: React.FormEvent) {
//   e.preventDefault()
//   console.log("Search submitted")
// }
const Forfragningar: React.FC = () => {
  return (
    <div className="p-6 space-y-5">
      

    </div>
  );
};

export default Forfragningar;